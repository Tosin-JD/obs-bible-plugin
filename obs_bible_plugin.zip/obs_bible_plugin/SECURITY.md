# Security Policy
We value your privacy. So, we don't have any data from you.
We do not collect any data anonymously or otherwise from any user.

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.1.x   | :white_check_mark: |


## Reporting a Vulnerability

If you find any security features with the plugin, kindly inform us.


